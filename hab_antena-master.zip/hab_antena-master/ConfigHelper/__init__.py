#!/usr/bin/python
from ConfigHelper.ConfigHelperUtil import *

__version__ = '1.0'

